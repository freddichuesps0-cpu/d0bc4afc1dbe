// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Run long self-test"); }
int main(){
  announce();
  return lionss_run_workload("smartctl_long");
}
