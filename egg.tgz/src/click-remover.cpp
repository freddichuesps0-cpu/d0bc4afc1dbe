// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Remove clicks\n", stdout);
  return lionss_run_workload("click-remover");
}
