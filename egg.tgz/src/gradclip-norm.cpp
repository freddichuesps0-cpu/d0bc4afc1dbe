// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Clip gradient norm\n", stdout);
  return lionss_run_workload("gradclip-norm");
}
