// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Adapt data rate\n", stdout);
  return lionss_run_workload("LorawanAdr");
}
