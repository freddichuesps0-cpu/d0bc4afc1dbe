// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Render halcyon calm"); }
int main(){
  announce();
  return lionss_run_workload("Halcyon");
}
