// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Evaluate comptime blocks\n", stdout);
  return lionss_run_workload("zigComptime");
}
