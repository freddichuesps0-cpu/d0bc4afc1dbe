// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Measure integrated LUFS\n", stdout);
  return lionss_run_workload("loudness_lufs");
}
