// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("FFT via Bluestein"); }
int main(){
  announce();
  return lionss_run_workload("fft_bluestein");
}
